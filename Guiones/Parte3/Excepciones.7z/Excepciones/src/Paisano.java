/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manuel.lama
 */
public class Paisano extends Personaje {
    
    public Paisano(String nombre) {
        super(nombre);
    }
}
