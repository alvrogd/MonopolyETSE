/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manuel.lama
 */
public class Soldado extends Personaje implements Comandos, Comandos3 {
    
    public Soldado(String nombre) {
        super(nombre);
    }
    
    public void mover() {
        
    }
    
    @Override
    public void recolectar(String direccion) throws ExcepcionDeRecolectar {
        throw new ExcepcionDeRecolectar("Un soldado no puede recolectar");
    }
}
