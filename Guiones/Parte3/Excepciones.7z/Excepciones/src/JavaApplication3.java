
import java.util.HashMap;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author manuel.lama
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashMap<String, Personaje> personajes= new HashMap<>();
        personajes.put("luis", new Soldado("luis"));
        personajes.put("pedro", new Paisano("pedro"));
        personajes.put("maria", new Paisano("maria"));
        Scanner leer= new Scanner(System.in);
        String comando= leer.nextLine();
        String[] campos= comando.split(" ");
        try {
            switch(campos[0]) {
                case "recolectar":
                    Personaje pers= personajes.get(campos[1]);
                    if(pers!=null) {
                        pers.recolectar(campos[2]);
                    }
            } 
        } catch(ExcepcionDeRecolectar exception) {
            System.out.println(exception.getMessage());
        } finally {
            System.out.println("Excepcion ocurrida");
        }
    }    
}
